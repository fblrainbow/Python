#!/bin/bash
case "$variable" in 
abc) echo "\$variable = abc" ;;
xyz) echo "\$cariable = xyz";;
esac
