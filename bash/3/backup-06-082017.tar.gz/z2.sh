123.txt
array.sh
case-1.sh
case.bak
case.sh
combined_file
com.sh
cp.sh
daimakuai.sh
dakuohao.sh
maohao.sh
rpm-1.sh
z1.sh
z2.sh
地址                     类型    硬件地址            标志  Mask            接口
192.168.0.115            ether   84:38:38:05:3b:8c   C                     enp0s31f6
192.168.0.239            ether   f8:bc:12:a9:ce:2e   C                     enp0s31f6
192.168.0.87             ether   b0:e2:35:ca:26:33   C                     enp0s31f6
192.168.0.253            ether   00:09:ee:00:09:ed   C                     enp0s31f6
