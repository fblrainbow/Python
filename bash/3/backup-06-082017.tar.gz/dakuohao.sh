#!/bin/bash
echo {case-1.sh,com.sh}\ :{\ A," B"," C"}
