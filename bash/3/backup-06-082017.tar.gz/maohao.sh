#!/bin/bash
:
echo $?
