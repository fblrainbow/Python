#!/bin/bash
Array[1]=slot_1
echo ${Array[1]}
