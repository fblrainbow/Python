#!/bin/bash
cp case.{sh,bak}
